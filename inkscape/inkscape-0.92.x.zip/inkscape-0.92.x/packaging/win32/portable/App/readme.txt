The files in this directory are necessary for Inkscape Portable to function.  There is normally no need to directly access or alter any of the files within these directories.
