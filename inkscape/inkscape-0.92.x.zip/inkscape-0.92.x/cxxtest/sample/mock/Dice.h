#ifndef __DICE_H
#define __DICE_H

class Dice
{
public:
    Dice();
    
    unsigned roll();
};

#endif // __DICE_H

