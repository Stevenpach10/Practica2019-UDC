Installation for Mac OS X users
===============================

We try to keep the Wiki pages on compiling Inkscape up-to-date and 
comprehensive. It is here: 

http://wiki.inkscape.org/wiki/index.php/CompilingMacOsX

For a brief overview: 

We suggest to use macports (http://macports.org) in order to achieve all
the necessary components and libraries. Then there is a mighty tool called
"osx-build.sh" in the packaging/macosx directory of the unpacked tarball.
This script will do most of the work for you. 

