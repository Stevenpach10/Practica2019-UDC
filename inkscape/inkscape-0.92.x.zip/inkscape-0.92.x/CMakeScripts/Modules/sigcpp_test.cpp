/*
 * Building this using:

 g++ `pkg-config --cflags sigc++-2.0` sigcpp_test.cpp

 Results in an error.
 * */
#include <stddef.h>
#include <string>
#include <sigc++/signal.h>

int main()
{
    return 0;
}
