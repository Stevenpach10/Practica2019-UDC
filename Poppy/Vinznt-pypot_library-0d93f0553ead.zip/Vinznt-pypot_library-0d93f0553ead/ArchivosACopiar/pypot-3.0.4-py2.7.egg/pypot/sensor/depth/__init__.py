try:
    from .sonar import SonarSensor

except ImportError:
    pass
