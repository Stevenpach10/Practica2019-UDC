try:
    from .imu import IMU
except ImportError:
    pass