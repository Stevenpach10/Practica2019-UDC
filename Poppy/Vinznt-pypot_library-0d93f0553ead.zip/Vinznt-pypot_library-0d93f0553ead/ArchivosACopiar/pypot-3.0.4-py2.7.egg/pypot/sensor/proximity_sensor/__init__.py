try:
    from .proximitysensor import ProximitySensor
except ImportError:
    pass
